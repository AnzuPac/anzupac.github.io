import { NextResponse } from 'next/server';
import { slugify } from '@/lib/slug';
import { initSchema, query, one } from '@/lib/db';
import { requireAuthor } from '@/lib/author';
import { getWork } from '@/lib/repo';




/** Мои произведения автора */
export async function GET() {
  const s = await requireAuthor();
  if (!s) return NextResponse.json({ error: 'forbidden' }, { status: 403 });
  await initSchema();
  const works = await query(
    `SELECT w.id, w.slug, w.title, w.type, w.status, w.completion, w.words_total, w.cover_path, w.updated_at,
            w.views_total,
            (SELECT CAST(COUNT(*) AS INTEGER) FROM chapters c WHERE c.work_id = w.id AND c.status = 'published') AS chapters,
            (SELECT CAST(COUNT(DISTINCT p.user_id) AS INTEGER) FROM reading_progress p WHERE p.work_id = w.id) AS readers
       FROM works w WHERE w.author_id = $1 ORDER BY w.updated_at DESC`, [s.uid]
  );
  return NextResponse.json({ works });
}

/** Создать или обновить произведение (черновик) */
export async function POST(req: Request) {
  const s = await requireAuthor();
  if (!s) return NextResponse.json({ error: 'forbidden' }, { status: 403 });
  const b = await req.json().catch(() => null);
  const title = String(b?.title || '').trim();
  if (!title) return NextResponse.json({ error: 'title_required' }, { status: 400 });
  await initSchema();

  const slugInput = String(b?.slug || '').trim();
  if (slugInput) {
    const existing = await one<{ id: number; author_id: number }>('SELECT id, author_id FROM works WHERE slug = $1', [slugInput]);
    if (!existing || existing.author_id !== s.uid) return NextResponse.json({ error: 'not_found' }, { status: 404 });
    await query(
      `UPDATE works SET title = $2, description = $3, age_rating = $4, completion = $5, updated_at = now() WHERE id = $1`,
      [existing.id, title, String(b?.description || ''), Number(b?.ageRating) || 0, b?.completion === 'completed' ? 'completed' : 'ongoing']
    );
    return NextResponse.json({ ok: true, work: { id: existing.id, slug: slugInput } });
  }

  const slug = slugify(title);
  const wtype = b?.type === 'comic' ? 'comic' : 'novel';
  const rows = await query<{ id: number; slug: string }>(
    `INSERT INTO works (slug, author_id, original_language, status, completion, age_rating, title, description, type)
     VALUES ($1,$2,'sr','draft',$3,$4,$5,$6,$7) RETURNING id, slug`,
    [slug, s.uid, b?.completion === 'completed' ? 'completed' : 'ongoing', Number(b?.ageRating) || 0, title, String(b?.description || ''), wtype]
  );
  return NextResponse.json({ ok: true, work: rows[0] });
}
